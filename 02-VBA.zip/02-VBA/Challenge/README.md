# Module 2 | Assignment - Wall Street

Explore green energy stock performance by analyzing financial data using VBA.
